from bs4 import BeautifulSoup

def clean(pages):
    txt=""
    for h in pages:
        s=BeautifulSoup(h,"html.parser")
        txt+=s.get_text()+"\n"
    return txt[:15000]
