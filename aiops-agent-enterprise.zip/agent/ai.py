from openai import OpenAI
client=OpenAI()

def enrich(text):
    prompt=f'''
Extract enterprise SRE structured JSON:

Include:
- application_name
- description
- api_details (endpoints, request/response)
- components (services/modules)
- data_flow
- infra (db, cloud, k8s)
- runbook_steps
- adr_decisions

CONTENT:
{text}
'''
    r=client.chat.completions.create(
        model="gpt-5.3",
        messages=[{"role":"user","content":prompt}],
        temperature=0.2
    )
    return r.choices[0].message.content
