import json, os
from crawler import crawl
from parser import clean
from ai import enrich
from generator import generate_all
from structure import ensure_structure

def run(url):
    ensure_structure()
    pages = crawl(url)
    text = clean(pages)
    data = json.loads(enrich(text))
    generate_all(data)
    return data
