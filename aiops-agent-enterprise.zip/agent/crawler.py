from playwright.sync_api import sync_playwright

def crawl(url):
    pages=[]
    with sync_playwright() as p:
        b=p.chromium.launch()
        page=b.new_page()
        page.goto(url)
        page.wait_for_timeout(3000)
        pages.append(page.content())
        b.close()
    return pages
