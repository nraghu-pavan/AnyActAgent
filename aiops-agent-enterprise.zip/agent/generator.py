import os

def write(path, content):
    with open(path,"w") as f:
        f.write(content)

def generate_all(data):

    # Runbook
    write("doc/runbook.md", data.get("runbook_steps",""))

    # API docs
    write("doc/api/api.md", data.get("api_details",""))

    # C4 diagrams
    write("doc/c4/backend-overview.c4.md", data.get("components",""))
    write("doc/c4/system-context.c3.md", data.get("infra",""))

    # Data flow
    write("doc/c4/data-flow.md", data.get("data_flow",""))

    # ADR
    write("doc/adr/adr-001.md", data.get("adr_decisions",""))

    # Summary
    write("doc/summary.md", data.get("description",""))
