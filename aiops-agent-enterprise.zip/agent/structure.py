import os

def ensure_structure():
    os.makedirs("doc/adr", exist_ok=True)
    os.makedirs("doc/c4", exist_ok=True)
    os.makedirs("doc/api", exist_ok=True)
