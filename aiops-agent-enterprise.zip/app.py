import streamlit as st
from agent.executor import run

st.title("Enterprise AIOps Agent")

url = st.text_input("Enter Confluence URL")

if st.button("Run Agent"):
    data = run(url)
    st.success("Docs Generated")
    st.json(data)
