# Enterprise SRE AIOps Agent

MANDATORY RULES:
1. Ensure /doc structure exists
2. Generate:
   - Runbook
   - ADR
   - C4 (L3 + L4)
   - API docs
3. Extract:
   - APIs
   - Components
   - Data flows
   - Infra
4. Use OpenAI for reasoning + enrichment
5. Always update existing docs
