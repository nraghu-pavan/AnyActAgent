from .crawler import crawl
from .parser import clean
from .vector_store import add, search
from .agents import planner_agent, runbook_agent
import os

def run(url):
    agent_md = open("agent.md").read()

    pages = crawl(url)
    text = clean(pages)

    add(text)

    context = "\n".join(search("SRE runbook incident escalation"))

    plan = planner_agent(agent_md, context)
    runbook = runbook_agent(agent_md, plan)

    os.makedirs("doc", exist_ok=True)
    with open("doc/runbook.md", "w") as f:
        f.write(runbook)

    return runbook
