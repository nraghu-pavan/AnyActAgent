from playwright.sync_api import sync_playwright

def crawl(url, max_pages=10):
    pages=[]
    with sync_playwright() as p:
        b=p.chromium.launch()
        page=b.new_page()
        page.goto(url)
        page.wait_for_timeout(3000)
        pages.append(page.content())

        links = page.query_selector_all("a")
        urls=[]
        for l in links:
            h=l.get_attribute("href")
            if h and "/wiki/" in h:
                urls.append(h)

        for u in list(set(urls))[:max_pages]:
            try:
                page.goto(u)
                page.wait_for_timeout(2000)
                pages.append(page.content())
            except:
                pass

        b.close()
    return pages
