import faiss, numpy as np, os
from openai import OpenAI

client = OpenAI()
DIM = 1536

os.makedirs("data", exist_ok=True)
INDEX_PATH = "data/faiss.index"
STORE_PATH = "data/store.npy"

if os.path.exists(INDEX_PATH):
    index = faiss.read_index(INDEX_PATH)
    store = list(np.load(STORE_PATH, allow_pickle=True))
else:
    index = faiss.IndexFlatL2(DIM)
    store = []

def embed(text):
    e = client.embeddings.create(
        model="text-embedding-3-small",
        input=text
    )
    return np.array(e.data[0].embedding, dtype="float32")

def add(text):
    vec = embed(text)
    index.add(np.array([vec]))
    store.append(text)
    faiss.write_index(index, INDEX_PATH)
    np.save(STORE_PATH, store)

def search(query, k=5):
    vec = embed(query)
    D, I = index.search(np.array([vec]), k)
    return [store[i] for i in I[0] if i < len(store)]
