from bs4 import BeautifulSoup

def clean(pages):
    txt=""
    for p in pages:
        s=BeautifulSoup(p,"html.parser")
        txt+=s.get_text()+"\n"
    return txt[:20000]
