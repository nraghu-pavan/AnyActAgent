from openai import OpenAI

client = OpenAI()

def planner_agent(agent_md, context):
    return client.chat.completions.create(
        model="gpt-5.3",
        messages=[
            {"role":"system","content":agent_md},
            {"role":"user","content":"Create structured SRE plan:\n"+context}
        ]
    ).choices[0].message.content

def runbook_agent(agent_md, plan):
    return client.chat.completions.create(
        model="gpt-5.3",
        messages=[
            {"role":"system","content":agent_md},
            {"role":"user","content":"Generate full runbook:\n"+plan}
        ]
    ).choices[0].message.content
