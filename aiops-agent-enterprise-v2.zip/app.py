import streamlit as st
from agent.executor import run

st.title("Enterprise AIOps Multi-Agent")

url = st.text_input("Enter Confluence URL")

if st.button("Run"):
    out = run(url)
    st.success("Generated")
    st.markdown(out)
