import streamlit as st
from agent.agent_executor import run_agent
from agent.vector_store import search

st.title("🧠 AIOps Agent Platform")

url = st.text_input("Enter Confluence URL")

if st.button("Generate Docs"):
    data = run_agent(url)
    st.success("Docs Generated!")
    st.subheader("Description")
    st.write(data.get("description",""))

query = st.text_input("Search incidents / fixes")

if st.button("Search"):
    results = search(query)
    for r in results:
        st.write(r)
