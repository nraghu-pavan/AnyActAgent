from openai import OpenAI
client = OpenAI()

def process_text(text):
    prompt = f"""
You are an expert SRE.

Extract structured JSON:
- application_name
- description
- slo_details
- observability
- incidents
- runbook_steps
- dependencies
- escalation
- risks

CONTENT:
{text}
"""

    response = client.chat.completions.create(
        model="gpt-5.3",
        messages=[{"role": "user", "content": prompt}],
        temperature=0.2
    )
    return response.choices[0].message.content
