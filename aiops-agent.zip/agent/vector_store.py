import faiss
import numpy as np
from openai import OpenAI

client = OpenAI()
dimension = 1536
index = faiss.IndexFlatL2(dimension)
store = []

def get_embedding(text):
    emb = client.embeddings.create(
        model="text-embedding-3-small",
        input=text
    )
    return np.array(emb.data[0].embedding, dtype="float32")

def add_to_vector(text):
    vec = get_embedding(text)
    index.add(np.array([vec]))
    store.append(text)

def search(query, k=3):
    q_vec = get_embedding(query)
    D, I = index.search(np.array([q_vec]), k)
    return [store[i] for i in I[0]]
