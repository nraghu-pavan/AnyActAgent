from bs4 import BeautifulSoup

def clean_text(html_pages):
    all_text = ""
    for html in html_pages:
        soup = BeautifulSoup(html, "html.parser")
        for tag in soup(["script", "style"]):
            tag.decompose()
        text = soup.get_text(separator="\n")
        all_text += text + "\n\n"
    return all_text[:15000]
