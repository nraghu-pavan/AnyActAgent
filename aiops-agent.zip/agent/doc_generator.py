import os

def generate_docs(data):
    os.makedirs("doc/c4", exist_ok=True)
    os.makedirs("doc/adr", exist_ok=True)
    os.makedirs("doc/api", exist_ok=True)

    with open("doc/runbook.md", "w") as f:
        f.write(f"# Runbook\n\n{data.get('runbook_steps','')}")

    with open("doc/c4/system-context.c3.md", "w") as f:
        f.write(data.get("dependencies",""))

    with open("doc/adr/adr-001.md", "w") as f:
        f.write(f"Decision:\n{data.get('description','')}")

    with open("doc/api/api.md", "w") as f:
        f.write(data.get("observability",""))

    with open("doc/CHANGELOG.md", "w") as f:
        f.write("Initial auto-generated docs")
