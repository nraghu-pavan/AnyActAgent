from playwright.sync_api import sync_playwright

MAX_PAGES = 10

def crawl_confluence(url):
    pages = []
    with sync_playwright() as p:
        browser = p.chromium.launch()
        page = browser.new_page()
        page.goto(url)
        page.wait_for_timeout(4000)
        pages.append(page.content())

        links = page.query_selector_all("a")
        child_links = []
        for l in links:
            href = l.get_attribute("href")
            if href and "/wiki/" in href:
                child_links.append(href)

        for link in list(set(child_links))[:MAX_PAGES]:
            try:
                page.goto(link)
                page.wait_for_timeout(3000)
                pages.append(page.content())
            except:
                pass

        browser.close()
    return pages
