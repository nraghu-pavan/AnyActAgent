import json
from .confluence_crawler import crawl_confluence
from .parser import clean_text
from .openai_processor import process_text
from .doc_generator import generate_docs
from .vector_store import add_to_vector

def run_agent(url):
    pages = crawl_confluence(url)
    text = clean_text(pages)
    ai_output = process_text(text)
    data = json.loads(ai_output)
    generate_docs(data)
    add_to_vector(text)
    return data
