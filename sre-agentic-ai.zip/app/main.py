from fastapi import FastAPI

app = FastAPI()

@app.get("/")
def home():
    return {"message": "SRE Agentic AI running"}
